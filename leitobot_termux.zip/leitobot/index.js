const { default: makeWASocket, useMultiFileAuthState, DisconnectReason } = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const P = require('pino');
const fs = require('fs');

const listas = {
    lista01: "",
    lista02: "",
    lista03: "",
    lista04: "",
    lista05: "",
    reglas: "",
    reglasFin: ""
};

const comandos = [
    "#tag", "#eliminar", "#ban", "#admins", "#grupo on", "#grupo off", "#info",
    "#reglas", "#bienvenida", "#leitobot", "#advertir", "#mutear", "#desmutear",
    "#lista01", "#lista02", "#lista03", "#lista04", "#lista05",
    "#actualizarlista01", "#actualizarlista02", "#actualizarlista03", "#actualizarlista04", "#actualizarlista05",
    "#actualizarreglas", "#actualizarreglasfinde"
];

async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('session');
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true,
        logger: P({ level: 'silent' })
    });

    sock.ev.on('messages.upsert', async ({ messages }) => {
        const msg = messages[0];
        if (!msg.message || msg.key.fromMe || !msg.pushName) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || "";
        const from = msg.key.remoteJid;

        if (text.startsWith("#")) {
            if (text === "#leitobot") {
                await sock.sendMessage(from, { text: "Leitobot aquí. ⭐" });
            } else if (text === "#tag") {
                const groupMetadata = await sock.groupMetadata(from);
                const participants = groupMetadata.participants.map(p => p.id);
                await sock.sendMessage(from, {
                    text: "¡Atención grupo!",
                    mentions: participants
                });
            } else if (text.startsWith("#lista")) {
                const num = text.match(/#lista(\d+)/)?.[1];
                if (num && listas["lista0" + num]) {
                    await sock.sendMessage(from, { text: listas["lista0" + num] });
                }
            } else if (text.startsWith("#actualizarlista")) {
                const num = text.match(/#actualizarlista(\d+)/)?.[1];
                const contenido = text.split(' ').slice(1).join(' ');
                if (num && contenido) {
                    listas["lista0" + num] = contenido;
                    await sock.sendMessage(from, { text: `Lista 0${num} actualizada.` });
                }
            } else if (text === "#reglas") {
                await sock.sendMessage(from, { text: listas.reglas || "No hay reglas configuradas aún." });
            } else if (text.startsWith("#actualizarreglasfinde")) {
                listas.reglasFin = text.split(' ').slice(1).join(' ');
                await sock.sendMessage(from, { text: "Reglas de fin de semana actualizadas." });
            } else if (text.startsWith("#actualizarreglas")) {
                listas.reglas = text.split(' ').slice(1).join(' ');
                await sock.sendMessage(from, { text: "Reglas actualizadas." });
            }
        }
    });

    sock.ev.on('creds.update', saveCreds);
}

startBot();